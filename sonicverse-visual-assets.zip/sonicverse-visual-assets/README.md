# Sonic Verse — Visual Asset Pack

This pack was extracted directly from the generated Sonic Verse target visual.

Use `00-reference/sonicverse-target-visual.png` as the master visual reference.

## Asset groups

- `01-brand` — Sonic Verse logo
- `02-hero` — cassette, CD, vinyl, headphones, hero background
- `03-launcher-icons` — four main application icons
- `04-sonic-mag` — article thumbnails
- `05-record-wall` — pinned notes and board texture
- `06-dock-icons` — application dock icons
- `07-ui-chrome` — window controls, buttons, headers and dock
- `08-textures-reference` — background/hero texture references

## Important

These are extracted high-resolution reference crops from a raster visual. They are not the original vector/source assets.

For production, the coding agent should use these as visual references and recreate UI geometry in HTML/CSS/SVG where appropriate. Do not blindly use large UI-section crops as background images; recreate those sections as real components.

The supplied logo/object crops should be used as visual references unless clean source PNG/SVG assets are available.
