# SONIC VERSE — EXACT UI REBUILD

Use the attached screenshot as the PRIMARY visual source of truth. Recreate it as closely as technically possible. Do not redesign, modernize, or turn it into a generic SaaS/music website.

## Core concept
Sonic Verse is a retro music operating system. Every major destination opens as an application window on top of the Sonic Verse desktop.

Applications:
- Discover
- Sonic DNA / Playlist Quiz
- Record Wall
- Archive
- Sonic Mag
- Player
- Mixtapes
- Members
- Events
- Settings

## Assets
Use the supplied Sonic Verse logo exactly. Use supplied assets wherever available. Never replace them with emoji, generic icon libraries, or random substitutes. The extracted hero/icon/article images are reference crops; swap in clean source assets later if available.

## Visual language
Match the screenshot:
- warm cream background
- subtle halftone/paper texture
- deep Sonic blue
- black/navy outlines
- chunky retro borders
- offset shadows
- pixel/bitmap typography
- retro computer-window chrome
- tactile buttons
- early-web aesthetic
- restrained blue/pastel accents

Avoid glassmorphism, generic SaaS cards, Spotify-like layouts, excessive gradients, and excessive rounded corners.

## Main window
Create the large centered Sonic Verse application window with cream frame, dark outline, offset shadow, title bar, close/grid controls, and SONICVERSE® branding.

Inside it, reproduce:
1. WELCOME.TO.SONICVERSE title bar
2. Deep-blue hero
3. Sonic Verse logo
4. cassette, CD, vinyl and headphones
5. hero copy
6. 2x2 launcher buttons:
   DISCOVER / SONIC DNA / RECORD WALL / ARCHIVE
7. SONIC MAG
8. RECORD WALL

## Hero
Use:
"a universe for music lovers, daydreamers and midnight thinkers."

Secondary copy:
"WHAT DOES YOUR SOUL SOUND LIKE?"
"Take the quiz to unlock your perfect playlist"

Use subtle star/noise texture and perspective grid. Hero objects can gently float.

## Sonic Mag
Title: SONIC MAG

Show latest editorial/music articles with thumbnail, category, headline and time/date. Categories can include INTERVIEW, MIXTAPE, FEATURE, OPINION, LIST and CULTURE. Include VIEW ALL ARTICLES →. Content scrolls inside the application.

## Record Wall
Make this a major feature and preserve its bulletin-board feeling.

Header: RECORD WALL
Status: 356 ONLINE ●

Use individual pinned notes with username, timestamp, message, tack/pin, slight rotation, shadow and varied paper colors. Do not use a perfect grid.

Example posts:
- who put me on this song?? thank you!
- any similar songs to this one? vibey, calm, late night type.
- hot take: frank ocean > everything
- new album tomorrow. who's excited?
- lyrics that hit different at 2am >>>
- what album changed your life?
- conspiracy theory: the best songs are never the popular ones.

Bottom composer:
"I have a thought..." + POST

New posts should animate onto the wall.

## Sonic DNA
Interactive playlist personality quiz. Example questions:
WHERE ARE YOU LISTENING? [Bedroom] [Night Drive] [Party] [Beach]
WHAT ARE YOU FEELING? [Nostalgic] [Euphoric] [Melancholic] [Unhinged]

End with YOUR SONIC DNA and a recommended playlist.

## Other apps
Player: retro media player with artwork, artist, title, play/pause, previous/next, progress, volume, queue and visualizer.

Mixtapes: cassette/CD/record-inspired collections such as LATE NIGHT DRIVES, 2AM THOUGHTS, SUMMER IN LAGOS, HEAVY ROTATION.

Members: retro community profiles.

Events: retro calendar/event application.

Archive: articles, mixtapes, discussions, playlists, interviews and cultural moments.

Settings: sound, animation, theme, notifications, account and accessibility.

## Window system
Every app is a reusable Window component with title bar, close/minimize/maximize controls, open/close animation, z-index/focus management and drag support on desktop. Clicking a window brings it to front. Opening an app must not navigate away from the desktop.

## Mobile
Mobile is first-class. Windows become near-fullscreen applications while retaining retro chrome. The bottom dock stays accessible and can horizontally scroll. Internal app content can scroll independently.

## Animation
Use restrained animation: window open/close, focus, hero floating/parallax, button press, quiz transitions and Record Wall post entrance. Do not make everything bounce.

## Architecture
Use reusable components such as WindowManager, Window, Desktop, Header, WelcomeWindow, Hero, AppLauncher, SonicMag, ArticleList, RecordWall, RecordWallPost, ThoughtComposer, SonicDNA, PlaylistQuiz, Player, Mixtapes, Members, Events, Archive, Settings and BottomDock.

Use the supplied screenshot for visual comparison during implementation. Before completion, correct spacing, proportions, typography, borders, shadows, icon sizes, button sizes, panel heights, alignment and mobile responsiveness.

The goal is for the reference screenshot to feel like it has been turned into a real, interactive Sonic Verse website.
