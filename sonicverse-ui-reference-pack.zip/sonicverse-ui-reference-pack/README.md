# Sonic Verse UI Reference Pack

Primary screenshot, Sonic Verse logo, extracted reference assets, and the coding-agent build prompt.

- reference/ — primary screenshot
- assets/brand/ — Sonic Verse logo
- assets/hero/ — hero-object reference crops
- assets/icons/ — UI icon reference crops
- assets/articles/ — article thumbnail reference crops
- prompt/ — implementation prompt

The cropped assets are reference crops. Replace them with clean SVG/PNG source assets when available.
